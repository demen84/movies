const navLinks = [
    {
        name: "Home",
        path: "/"
    },
    {
        name: "Form Validation",
        path: "form-validation"
    },
    {
        name: "List Movies",
        path: "list-movie"
    },
    {
        name: "News",
        path: "news"
    },
    {
        name: "About",
        path: "about"
    },
    {
        name: "Login",
        path: "login"
    },
    {
        name: "Register",
        path: "register"
    },
    {
        name: "Other",
        path: "other"
    }
];

export default navLinks;

export default function Footer() {
    return (
        <div className="mt-9">
            <h1 className="text-center text-3xl font-bold text-teal-700">FOOTER SESSION</h1>
        </div>
    )
}

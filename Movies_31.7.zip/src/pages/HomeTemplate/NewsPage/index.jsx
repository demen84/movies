

export default function NewsPage() {
    return (
        <div className="container mx-auto">
            <h1 className="font-bold text-2xl text-red-500 text-center mb-10">Trang tin tức điện ảnh</h1>
            <p className="text-center">Nơi cập nhật những thông tin mới nhất về điện ảnh</p>
        </div>
    )
}

import React from 'react'

export default function AddUserPage() {
    return (
        <div>
            <h1 className='text-3xl text-yellow-600 font-bold'>Add User Page</h1>
        </div>
    )
}

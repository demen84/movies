

export default function Dashboard() {
    return (
        <div>
            <h1 className='text-3xl text-purple-600 font-bold'>Dashboard</h1>
        </div>
    )
}

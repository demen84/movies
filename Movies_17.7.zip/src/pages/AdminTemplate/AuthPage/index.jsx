
export default function AuthPage() {
    return (
        <div>
            <h1 className="text-2xl text-blue-600 text-center font-bold">Authorized Page</h1>
        </div>
    )
}

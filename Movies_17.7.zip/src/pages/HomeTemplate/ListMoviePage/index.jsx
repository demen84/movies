

export default function ListMoviePage() {
    return (
        <div>
            <h1 className='text-3xl text-green-600 font-bold text-center'>List Movie Page</h1>
        </div>
    )
}

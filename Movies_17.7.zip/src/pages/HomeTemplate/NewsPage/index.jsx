

export default function NewsPage() {
    return (
        <div>
            <h1 className="font-bold text-2xl text-red-500 text-center">Trang tin tức điện ảnh</h1>
            <p>Nơi cập nhật những thông tin mới nhất về điện ảnh</p>
        </div>
    )
}



export default function AboutPage() {
    return (
        <div>
            <h1 className='text-3xl text-blue-600 font-bold text-center'>About Page</h1>
        </div>
    )
}

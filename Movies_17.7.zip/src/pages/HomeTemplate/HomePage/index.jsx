

export default function HomePage() {
    return (
        <div>
            <h1 className='text-3xl text-red-600 font-bold text-center'>Home Page</h1>
        </div>
    )
}
